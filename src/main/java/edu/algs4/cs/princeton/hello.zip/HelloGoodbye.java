/**
 * @ClassName HelloGoodbye
 * @Description TODO
 * @Author XiaoShuMu
 * @Version 1.0
 * @Create 2021-10-27 14:52
 * @Blog https://www.cnblogs.com/WLCYSYS/
 **/
public class HelloGoodbye {
    public static void main(String[] args) {
        System.out.println("Hello " + args[0] + " and " + args[1] + ".\n" +
                "Goodbye " + args[1] + " and " + args[0] + ".");
    }
}
